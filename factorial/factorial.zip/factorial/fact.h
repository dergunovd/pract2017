#pragma once
long double fact(int N);